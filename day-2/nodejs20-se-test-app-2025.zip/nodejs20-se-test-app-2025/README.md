# This folder/repo contains the application code for the Sparta Test App

## About the app
- "app" folder stores Sparta app
- uses Node JS v20
- Runs on port 3000
- Requires a web server (nginx)
